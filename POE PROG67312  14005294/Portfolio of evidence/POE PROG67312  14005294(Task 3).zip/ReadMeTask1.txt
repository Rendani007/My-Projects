Data structures

The data structures used are: 

- arrays
A C# array is basically a list of objects. Its defining traits are that all the objects are the same type (in most cases) and there is a specific number of them. 
The nature of an array allows for very fast access to elements based on their position within the list (otherwise known as the index).

- lists<>
List is the generic version of ArrayList, which means that it behaves exactly the same way, 
but within a specified type. 

- Regex function
The Regex class represents the .NET Framework's regular expression engine. 
It can be used to quickly parse large amounts of text to find specific character patterns; to extract, edit, 
replace, or delete text substrings; and to add the extracted strings to a collection to generate a report.

--------------------------------------------------------------------------------

How assembly is structured structure and why
-------------------------------------------------
- The test assembly is structured with in linear, conditional and loop 
  format which means that it contains if statements, loops and other forms of 
  structures for the purpose of decreasing complexity.

- There are 4 classes:Ferrari, lamborghini, mercedies and porsche
- within the methods there are multiple vehicle types that are assigned to each class
- The assembly is structured to sort by number of methods in a class in assending order.
- It also orders by average number of lines per method, and distunguishae all classes 
that have an avarage number of lines.

the test assembly also: 
- Displays all the interfaces in the assembly in alphabetical order
- Visually distinguishes any interfaces with no implementations as non-compliant to company
  standards;
- the user can select any interface and the datagrid will display all other interfaces
  besides the one selected  
--------------------------------------------------------------------------------

Compile the Program
---------------------------
- Open Visual Studio 
- Create DLL file
- Create classes and methods 
- add detaild within the methods to increase byte size 
--------------------------------------------------------------------------------
How to use the program
Refer to word document for Visual Instructions.

-------------------------------------------------------------------------------------
Task 3
-------------------------------------------------------------------------------------
To Display class hierarchy
- As you have loaded the ddl file on to the programe, select move on to the class 	
  hierarchy section and select "Class Hierarchy" button and the treeView form will display the information

To export the text file that shows the classes and hierarchy
- Next to the "Class Hierarchy" button there is a "Save to text" button that will 
  export a text file that shows the classes and hierarchy.

To display class relationship 
- When you move to the relationship of classes section, select 
  "Select Assembly" button, from there classes that have a relationship with eachother will be displayed.

To exit the application
- Once you are finnished with the program, select the exit application button. 
