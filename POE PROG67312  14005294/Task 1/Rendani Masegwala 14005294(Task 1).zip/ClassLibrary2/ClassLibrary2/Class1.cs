﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class Ferrari
    {
        public void LaFerrari()
        {
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
        }

        public void Portofino()
        {
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
        }

    }

    public class Lamborghini
    {
        public void perfomante()
        {
            Console.WriteLine("500Hp");
            Console.WriteLine("full lether interior");
            Console.WriteLine("");
            Console.WriteLine("ksjf s");
            Console.WriteLine("ksjf");
            Console.WriteLine("kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
        }
        public void aventador()
        {
            Console.WriteLine("400");
            Console.WriteLine("leather");
            Console.WriteLine("carbon fiber");
        }
        public void urus()
        {

        }
        public void Jotta()
        {

        }
    }

    public class Mercedes
    {
        public void GLE()
        {

        }
        public void AMGgtr()
        {
            Console.WriteLine("carbon");
            Console.WriteLine("20 inch rims");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
        }
        public void Sclass()
        {

        }
    }

    public class Porsche
    {
        public void Caymen()
        {
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf"); Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
        }
        public void Cayanne()
        {
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf"); 
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
        }
        public void Macan()
        {
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
            Console.WriteLine("ksjf sdkfjhsd kjsdf kjbsdf");
        }
    }

}
