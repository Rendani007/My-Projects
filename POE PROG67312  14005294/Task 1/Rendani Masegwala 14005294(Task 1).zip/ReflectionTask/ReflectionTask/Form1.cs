﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReflectionTask
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            //column positions and names
            InitializeComponent();
            dataGridView1.Columns.Add("1a", "Class");
            dataGridView1.Columns.Add("1b", "Number Methods");
            dataGridView2.Columns.Add("2a", "Class");
            dataGridView2.Columns.Add("2b", "Method");
            
            dataGridView3.Columns.Add("3a", "Class");
            dataGridView3.Columns.Add("3b", "Method");
            dataGridView3.Columns.Add("3c", "Byte Size");
            dataGridView4.Columns.Add("4a", "Name");//to do doublech what is meant by external refernce...

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public void info()
        {

            using (OpenFileDialog opf = new OpenFileDialog())
            {
                opf.ShowDialog();

                //Loads the conten of the assembly on the form
                Assembly load = Assembly.LoadFile(opf.FileName);
                int cntMethods = 0, countClass = 0;
                dataGridView4.Rows.Clear();
                dataGridView1.Rows.Clear();
                dataGridView2.Rows.Clear();
                dataGridView3.Rows.Clear();
                List<String> classList = new List<String>();
                List<String> methodList = new List<String>();

                Type[] Types = load.GetTypes();
                List<AssemblyName> ExternalRef = load.GetReferencedAssemblies().ToList();


                //START External Reference
                foreach (var Ref in ExternalRef)
                {
                    dataGridView4.Rows.Add(Ref.FullName);
                }

                dataGridView4.Sort(dataGridView4.Columns["4a"], ListSortDirection.Ascending);
                dataGridView4.AutoResizeColumns();
                dataGridView4.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                //END External Reference
                
                //loading bar
                int loadbarClassCount = 0;
                foreach (Type classesCount in Types)
                {
                    loadbarClassCount++;
                }

              
                
                ///getting the Class details
                foreach (Type cls in Types)
                {

                    textBox1.Text = cls.Assembly.ToString();

                    if (cls.IsAbstract)
                    {
                        Console.WriteLine("Abstract Class : " + cls.Name);
                    }
                    else if (cls.IsPublic)
                    {
                        Console.WriteLine("Public Class : " + cls.Name);
                        classList.Add(cls.Name);
                    }
                    else if (cls.IsSealed)
                    {
                        Console.WriteLine("Sealed Class : " + cls.Name);
                    }

                    //getting Methods details
                    MethodInfo[] methods = cls.GetMethods(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly | BindingFlags.Public);
                    foreach (MethodInfo method in methods)
                    {
                        try
                        {
                            MethodBody mb = method.GetMethodBody();//for method
                            Console.WriteLine("Public Method : " + method.Name);
                            cntMethods++;

                            dataGridView2.Rows.Add(cls.Name, method.Name, mb.GetILAsByteArray().Length);
                            dataGridView3.Rows.Add(cls.Name, method.Name, mb.GetILAsByteArray().Length);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("MethofInfo Error \n" + ex);
                        }

                    }
                    


                    dataGridView3.Sort(dataGridView3.Columns["3c"], ListSortDirection.Descending);
                    dataGridView3.AutoResizeColumns();
                    dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

                    Console.WriteLine("Num Of methods:  " + cntMethods);
                    methodList.Add(cntMethods.ToString());
                    cntMethods = 0;
                    countClass++;

                }
                int numofClasses = classList.Count;
                int numMethods = methodList.Count;
                string[,] classes2 = new string[numofClasses, numMethods];

                for (int i = 0; i < classList.Count; i++)
                {

                    dataGridView1.Rows.Add(classList[i], Int64.Parse(methodList[i]));

                }

                dataGridView1.Sort(dataGridView1.Columns["1b"], ListSortDirection.Descending);
                dataGridView1.AutoResizeColumns();
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            }


        }

        public void InfoLinesUser()
        {
            //try
            //{

            //    int gvLinesUserRowCount = dataGridView3.RowCount;

            //    button2.Visible = true;


            //    for (int i = 0; i <= gvLinesUserRowCount; i++)
            //    {

            //        while (Int32.Parse(dataGridView3.Rows[i].Cells[2].Value.ToString()) <= Int32.Parse(textBox2.Text))
            //        {

            //            dataGridView3.Rows.Remove(dataGridView3.Rows[i]);
            //            gvLinesUserRowCount--;
            //            dataGridView3.Refresh();
            //            Console.WriteLine(i + " " + gvLinesUserRowCount + " " + Int32.Parse(dataGridView3.Rows[i].Cells[2].Value.ToString()));
            //            // btnsearch.PerformStep();
            //        }

            //    }


            //    dataGridView3.Refresh();
            //    dataGridView3.AutoResizeColumns();
            //    dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            //    dataGridView3.Sort(dataGridView3.Columns["c"], ListSortDirection.Descending);
            //}
            //catch (Exception ex)
            //{

            //    Console.WriteLine("InfoLinesUser Error on Remove \n" + ex);
            //}
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                info();
            }
            catch (Exception ex)
            {
                MessageBox.Show("NOT A SUPPORTED FILE \n btnFile_Click \n" + ex.ToString());
            }
 
        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)//button for Filter
        {
            try
            {

                try
                {

                    int LURowCount = dataGridView3.RowCount;

                    button2.Visible = true;


                    for (int i = 0; i <= LURowCount; i++)
                    {

                        while (Int32.Parse(dataGridView3.Rows[i].Cells[2].Value.ToString()) <= Int32.Parse(textBox2.Text))
                        {

                            dataGridView3.Rows.Remove(dataGridView3.Rows[i]);
                            LURowCount--;
                            dataGridView3.Refresh();
                            Console.WriteLine(i + " " + LURowCount + " " + Int32.Parse(dataGridView3.Rows[i].Cells[2].Value.ToString()));
                            // btnsearch.PerformStep();
                        }

                    }


                    dataGridView3.Refresh();
                    dataGridView3.AutoResizeColumns();
                    dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                    dataGridView3.Sort(dataGridView3.Columns["3c"], ListSortDirection.Descending);
                }
                catch (Exception ex)
                {

                    Console.WriteLine("InfoLinesUser Error on Remove \n" + ex);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("SELECT ASSEMBLY FILE");
                Console.WriteLine("btnLinesUser_Click \n" + ex);
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
